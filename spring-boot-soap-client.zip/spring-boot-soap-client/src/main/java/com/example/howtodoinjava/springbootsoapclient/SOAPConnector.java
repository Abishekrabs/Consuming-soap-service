package com.example.howtodoinjava.springbootsoapclient;
 
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.example.howtodoinjava.schemas.school.Add;
 
public class SOAPConnector extends WebServiceGatewaySupport {
 
    public Object callWebService(String url, Add ad){
        return getWebServiceTemplate().marshalSendAndReceive(url, ad);
    }
}