package com.example.howtodoinjava.springbootsoapclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.example.howtodoinjava.schemas.school.AddResponse;


@SpringBootApplication
public class SpringBootSoapClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSoapClientApplication.class, args);
	
		SOAPConnector client = new SOAPConnector();
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        // this is the package name specified in the <generatePackage> specified in
        // pom.xml
        marshaller.setContextPath("com.example.howtodoinjava.schemas.school");    
        client.setMarshaller(marshaller);
        client.setUnmarshaller(marshaller);
        
//        int input1 = 4;
//        int input2 = 4;
//        Add ad = new Add();
//        ad.setIntA(input1);
//        ad.setIntB(input2);
        AddResponse response = client.callWebService(4,4);
        System.out.println("Add Result : "+response.getAddResult());
	}
}

	
