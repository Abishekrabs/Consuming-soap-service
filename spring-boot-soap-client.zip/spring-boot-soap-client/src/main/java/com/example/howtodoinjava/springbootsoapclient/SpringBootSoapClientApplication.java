package com.example.howtodoinjava.springbootsoapclient;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.howtodoinjava.schemas.school.Add;
import com.example.howtodoinjava.schemas.school.AddResponse;


@SpringBootApplication
public class SpringBootSoapClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSoapClientApplication.class, args);
	}
	
	  @Bean
	    CommandLineRunner lookup(SOAPConnector soapConnector) {
	        return AddResponse -> {
	            int input1 = 4;
	            int input2 = 4;
//	            if(args.length>0){
//	                name = args[0];
//	            }
	            Add ad = new Add();
	            ad.setIntA(input1);
	            ad.setIntB(input2);
	            AddResponse response =(AddResponse) soapConnector.callWebService("http://www.dneonline.com/calculator.asmx?wsdl", ad);
	            System.out.println("Got Response As below ========= : ");
	            System.out.println("Add Result : "+response.getAddResult());
	        };
	    }
	
	
}
