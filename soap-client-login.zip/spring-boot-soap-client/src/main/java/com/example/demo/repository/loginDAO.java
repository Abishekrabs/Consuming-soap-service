package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.login;

public interface loginDAO extends JpaRepository<login, Long> {

}
