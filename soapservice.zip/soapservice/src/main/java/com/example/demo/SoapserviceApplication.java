package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.demo.schemas.InputRequest;
import com.example.demo.schemas.InputResponse;

@SpringBootApplication
public class SoapserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapserviceApplication.class, args);
	}

	@Bean
	CommandLineRunner lookup(SoapClient soap) {
		return InputResponse -> {
			int input1 = 4;
			int input2 = 4;

			InputRequest request = new InputRequest();
			request.setInput1(input1);
			request.setInput2(input2);
			
			InputResponse response = soap.getInput(request);
			System.out.println("Got Response As below ========= : ");
			System.out.println("Output : "+response.getOutput());	
			};
	}
	
}
	
	
//	@Bean
//	CommandLineRunner lookup(SoapClient soap) {
//		return InputResponse -> {
//			int input1 = 4;
//			int input2 = 4;
//						
//			InputRequest request = new InputRequest();
//			request.setInput1(input1);
//			request.setInput2(input2);
//			InputResponse response =(InputResponse) soap.callWebService("http://www.dneonline.com/calculator.asmx?wsdl", request);
//			System.out.println("Got Response As below ========= : ");
//			System.out.println("Output : "+response.getOutput());
//		};
//	}
//	
	

