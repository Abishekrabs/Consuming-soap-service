package com.example.demo.schemas;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;



@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InputResponse", propOrder = {
    "output"
})
@XmlRootElement(name = "InputResponse")
public class InputResponse {

	  @XmlElement(required = true)
	    protected int output;

	  

	    /**
	     * Gets the value of the output property.
	     * 
	     */
	    public int getOutput() {
	        return output;
	    }

	    /**
	     * Sets the value of the output property.
	     * 
	     */
	    public void setOutput(int value) {
	        this.output = value;
	    }
	
}
