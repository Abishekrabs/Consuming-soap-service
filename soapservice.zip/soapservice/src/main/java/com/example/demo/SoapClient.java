package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import com.example.demo.schemas.InputRequest;
import com.example.demo.schemas.InputResponse;


public class SoapClient extends WebServiceGatewaySupport  {

	
	private static final Logger log = LoggerFactory.getLogger(SoapClient.class);

	public InputResponse getInput(InputRequest request) {

		request.getInput1();
		request.getInput2();

		log.info("Requesting input1 " + request.getInput1());
		log.info("Requesting input2 " + request.getInput2());
		
		InputResponse response = (InputResponse) getWebServiceTemplate()
				.marshalSendAndReceive("http://www.dneonline.com/calculator.asmx?wsdl", request,
						new SoapActionCallback(
								"https://spring.io/guides/gs/consuming-web-service/InputRequest"));

		return response;
	}
	
}
	

//    public Object callWebService(String url, InputRequest request){
//        return getWebServiceTemplate().marshalSendAndReceive(url, request);
//    }	
//}
