package com.example.demo.schemas;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InputRequest", propOrder = {
    "input1",
    "input2"
})
@XmlRootElement(name = "InputRequest")
public class InputRequest {

	 @XmlElement(required = true)
	    protected int input1;
	    @XmlElement(required = true)
	    protected int input2;

	  

	    /**
	     * Gets the value of the Input1 property.
	     * 
	     */
	    public int getInput1() {
	        return input1;
	    }

	    /**
	     * Sets the value of the Input1 property.
	     * 
	     */
	    public void setInput1(int value) {
	        this.input1 = value;
	    }

	    /**
	     * Gets the value of the Input2 property.
	     * 
	     */
	    public int getInput2() {
	        return input2;
	    }

	    /**
	     * Sets the value of the Input2 property.
	     * 
	     */
	    public void setInput2(int value) {
	        this.input2 = value;
	    }

	
}
